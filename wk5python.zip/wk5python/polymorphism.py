# Polymorphism Example: Vehicles 

class Vehicle:
    def move(self):
        pass   

class Car(Vehicle):
    def move(self):
        return "Driving on the road "

class Plane(Vehicle):
    def move(self):
        return "Flying in the sky "

class Bike(Vehicle):
    def move(self):
        return "Pedaling along the path "

class Boat(Vehicle):
    def move(self):
        return "Sailing on the water "

# Function to demonstrate polymorphism
def vehicle_action(vehicle):
    print(vehicle.move())

# Create objects
car = Car()
plane = Plane()
bike = Bike()
boat = Boat()

# Call the same method on different objects
vehicle_action(car)    # Driving on the road 
vehicle_action(plane)  # Flying in the sky 
vehicle_action(bike)   # Pedaling along the path 
vehicle_action(boat)   # Sailing on the water 

