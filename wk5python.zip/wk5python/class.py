class Smartphone:
    def __init__(self, brand, model, storage_gb, battery_percent):
        self.brand = brand
        self.model = model
        self.storage_gb = storage_gb
        self.battery_percent = battery_percent
    def make_call(self, number):
        if self.battery_percent > 0:
            print(f"Calling {number} from {self.brand} {self.model}...")
            self.battery_percent -= 1
        else:
            print("Battery dead. Please charge your phone.")
    def charge(self, amount):
        self.battery_percent = min(100, self.battery_percent + amount)
        print(f"Charged to {self.battery_percent}%")
        # Inheritance example: Smartphone subclass
class GamingSmartphone(Smartphone):
    def __init__(self, brand, model, storage_gb, battery_percent, cooling_system):
        super().__init__(brand, model, storage_gb, battery_percent)
        self.cooling_system = cooling_system
    def play_game(self, game_name):
        if self.battery_percent > 5:
            print(f"Playing {game_name} on {self.brand} {self.model} with {self.cooling_system} cooling.")
            self.battery_percent -= 5
        else:
            print("Battery too low to play games.")
# Example usage
phone = Smartphone("Apple", "iPhone 14", 128, 50)
phone.make_call("123-456-7890")
phone.charge(30)
gaming_phone = GamingSmartphone("ASUS", "ROG Phone 6", 256, 80, "liquid cooling")
gaming_phone.play_game("Call of Duty")
gaming_phone.make_call("987-654-3210")